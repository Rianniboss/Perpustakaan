<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EbookController extends Controller
{
    public function index()
    {
        $ebooks = Ebook::latest()->paginate(10);
        return view('ebooks.index', compact('ebooks'));
    }

    public function create()
    {
        return view('ebooks.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'author' => 'required|string|max:255',
            'description' => 'nullable|string',
            'file' => 'required|mimes:pdf|max:10240', // 10MB max
            'cover' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        $filePath = $request->file('file')->store('ebooks', 'public');
        $coverPath = $request->hasFile('cover')
            ? $request->file('cover')->store('ebook_covers', 'public')
            : null;

        Ebook::create([
            'title' => $request->title,
            'author' => $request->author,
            'description' => $request->description,
            'file_path' => $filePath,
            'cover_image' => $coverPath,
            'uploaded_by' => auth()->id(),
        ]);

        return redirect()->route('ebooks.index')->with('success', 'E-Book berhasil diunggah.');
    }
}
