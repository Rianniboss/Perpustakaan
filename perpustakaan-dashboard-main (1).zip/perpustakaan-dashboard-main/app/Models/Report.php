<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    use HasFactory;

    protected $fillable = [
        'total_users',
        'total_books',
        'total_borrowings',
        'total_returns',
        'report_date',
    ];

    protected $casts = [
        'report_date' => 'date',
    ];
}
